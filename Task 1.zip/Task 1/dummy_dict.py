def make_dummy_data(start, end, step):
    data = {}  

    for num in range(start, end, step):
        key = "key" + str(num)
        value = "value" + str(num)
        data[key] = value  

    return data

try:
    print("Let's make some dummy dict data.")
    start = int(input("Start number: "))
    end = int(input("End number: "))
    step = int(input("Step size: "))

    if step == 0:
        print("Step cannot be zero. Try again.")
    else:
        dummy = make_dummy_data(start, end, step)
        print("\nHere's your dummy dict:\n")
        print(dummy)

except Exception as e:
    print("Something went wrong. Did you enter numbers?")
    print("Error:", e)
