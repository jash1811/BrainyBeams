import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk

class ImageViewerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Multiple Image Viewer")
        self.root.geometry("800x600")
        self.root.configure(bg="white")

        self.image_paths = []
        self.current_index = 0
        self.image_label = tk.Label(root, bg="white")
        self.image_label.pack(expand=True)

        # Control buttons
        button_frame = tk.Frame(root, bg="white")
        button_frame.pack(pady=10)

        self.prev_button = tk.Button(button_frame, text="<< Previous", command=self.show_prev)
        self.prev_button.grid(row=0, column=0, padx=10)

        self.next_button = tk.Button(button_frame, text="Next >>", command=self.show_next)
        self.next_button.grid(row=0, column=1, padx=10)

        self.load_button = tk.Button(button_frame, text="Load Images", command=self.load_images)
        self.load_button.grid(row=0, column=2, padx=10)

    def load_images(self):
        filetypes = [("Image files", "*.jpg *.jpeg *.png *.bmp *.gif")]
        paths = filedialog.askopenfilenames(title="Select Images", filetypes=filetypes)
        if paths:
            self.image_paths = paths
            self.current_index = 0
            self.show_image()

    def show_image(self):
        if not self.image_paths:
            return

        img_path = self.image_paths[self.current_index]
        img = Image.open(img_path)
        img = img.resize((700, 500), Image.Resampling.LANCZOS)
        self.tk_image = ImageTk.PhotoImage(img)
        self.image_label.config(image=self.tk_image)

    def show_next(self):
        if self.image_paths and self.current_index < len(self.image_paths) - 1:
            self.current_index += 1
            self.show_image()

    def show_prev(self):
        if self.image_paths and self.current_index > 0:
            self.current_index -= 1
            self.show_image()

if __name__ == "__main__":
    root = tk.Tk()
    app = ImageViewerApp(root)
    root.mainloop()
