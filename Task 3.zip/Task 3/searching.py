import yt_dlp

def get_youtube_links(search_term, max_results=5):
    ydl_opts = {
        'quiet': True,
        'extract_flat': 'in_playlist',
        'skip_download': True,
        'force_generic_extractor': True,
    }

    search_query = f"ytsearch{max_results}:{search_term}"
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(search_query, download=False)
        results = info.get('entries', [])
        links = [entry['url'] for entry in results]
        return links

# 🔍 Test it
search = input("Enter search term: ")
results = get_youtube_links(search)

print("\nTop YouTube Results:")
for i, link in enumerate(results, 1):
    print(f"{i}. https://www.youtube.com/watch?v={link}")
